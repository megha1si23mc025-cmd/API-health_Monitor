from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import get_db
from datetime import datetime, timedelta
import models, auth, ai_service
from scheduler import schedule_monitor, remove_monitor_job, check_monitor
import secrets

router = APIRouter()
templates = Jinja2Templates(directory="templates")

def require_user(request: Request, db: Session):
    user = auth.get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=302, headers={"Location": "/login"})
    return user

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    monitors = db.query(models.Monitor).filter(models.Monitor.user_id == user.id).all()
    total = len(monitors)
    up_count = sum(1 for m in monitors if m.current_status == "up")
    down_count = sum(1 for m in monitors if m.current_status == "down")
    degraded_count = sum(1 for m in monitors if m.current_status == "degraded")
    # Avg response time from last 24h
    since = datetime.utcnow() - timedelta(hours=24)
    all_checks = []
    for m in monitors:
        checks = db.query(models.CheckHistory).filter(
            models.CheckHistory.monitor_id == m.id,
            models.CheckHistory.checked_at >= since,
            models.CheckHistory.response_time_ms != None
        ).all()
        all_checks.extend(checks)
    avg_response = round(sum(c.response_time_ms for c in all_checks) / len(all_checks), 1) if all_checks else 0
    recent_incidents = db.query(models.Incident).join(models.Monitor).filter(
        models.Monitor.user_id == user.id
    ).order_by(models.Incident.started_at.desc()).limit(5).all()
    return templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user, "monitors": monitors,
        "total": total, "up_count": up_count, "down_count": down_count,
        "degraded_count": degraded_count, "avg_response": avg_response,
        "recent_incidents": recent_incidents
    })

@router.get("/monitors/add", response_class=HTMLResponse)
async def add_monitor_page(request: Request, db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    return templates.TemplateResponse("add_monitor.html", {"request": request, "user": user, "monitor": None, "error": None})

@router.post("/monitors/add")
async def add_monitor_submit(request: Request, name: str = Form(...), url: str = Form(...),
    method: str = Form("GET"), interval_minutes: int = Form(5),
    expected_status_code: int = Form(200), timeout_seconds: int = Form(30),
    db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    monitor = models.Monitor(
        user_id=user.id, name=name, url=url, method=method,
        interval_minutes=interval_minutes, expected_status_code=expected_status_code,
        timeout_seconds=timeout_seconds, public_slug=secrets.token_urlsafe(8)
    )
    db.add(monitor)
    db.commit()
    db.refresh(monitor)
    schedule_monitor(monitor.id, monitor.interval_minutes)
    check_monitor(monitor.id)
    return RedirectResponse(url=f"/monitors/{monitor.id}", status_code=302)

@router.get("/monitors/{monitor_id}", response_class=HTMLResponse)
async def monitor_detail(monitor_id: int, request: Request, db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    monitor = db.query(models.Monitor).filter(
        models.Monitor.id == monitor_id, models.Monitor.user_id == user.id
    ).first()
    if not monitor:
        return RedirectResponse(url="/dashboard", status_code=302)
    since_24h = datetime.utcnow() - timedelta(hours=24)
    checks_24h = db.query(models.CheckHistory).filter(
        models.CheckHistory.monitor_id == monitor_id,
        models.CheckHistory.checked_at >= since_24h
    ).order_by(models.CheckHistory.checked_at.asc()).all()
    total_checks = len(checks_24h)
    up_checks = sum(1 for c in checks_24h if c.status == "up")
    uptime_percent = round((up_checks / total_checks * 100), 2) if total_checks > 0 else 0
    response_times = [c.response_time_ms for c in checks_24h if c.response_time_ms]
    avg_response = round(sum(response_times) / len(response_times), 1) if response_times else 0
    chart_labels = [c.checked_at.strftime("%H:%M") for c in checks_24h]
    chart_data = [round(c.response_time_ms, 1) if c.response_time_ms else None for c in checks_24h]
    incidents = db.query(models.Incident).filter(
        models.Incident.monitor_id == monitor_id
    ).order_by(models.Incident.started_at.desc()).limit(10).all()
    insight = ai_service.get_uptime_insight(uptime_percent, avg_response)
    diagnosis = None
    if monitor.current_status == "down":
        last_check = db.query(models.CheckHistory).filter(
            models.CheckHistory.monitor_id == monitor_id
        ).order_by(models.CheckHistory.checked_at.desc()).first()
        if last_check:
            diagnosis = ai_service.diagnose_failure(
                monitor.url, last_check.status_code or 0, last_check.error_message or ""
            )
    return templates.TemplateResponse("monitor_detail.html", {
        "request": request, "user": user, "monitor": monitor,
        "uptime_percent": uptime_percent, "avg_response": avg_response,
        "total_checks": total_checks, "chart_labels": chart_labels,
        "chart_data": chart_data, "incidents": incidents,
        "insight": insight, "diagnosis": diagnosis
    })

@router.post("/monitors/{monitor_id}/delete")
async def delete_monitor(monitor_id: int, request: Request, db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    monitor = db.query(models.Monitor).filter(
        models.Monitor.id == monitor_id, models.Monitor.user_id == user.id
    ).first()
    if monitor:
        remove_monitor_job(monitor_id)
        db.delete(monitor)
        db.commit()
    return RedirectResponse(url="/dashboard", status_code=302)

@router.post("/monitors/{monitor_id}/toggle")
async def toggle_monitor(monitor_id: int, request: Request, db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    monitor = db.query(models.Monitor).filter(
        models.Monitor.id == monitor_id, models.Monitor.user_id == user.id
    ).first()
    if monitor:
        monitor.is_active = not monitor.is_active
        if monitor.is_active:
            schedule_monitor(monitor.id, monitor.interval_minutes)
        else:
            remove_monitor_job(monitor.id)
        db.commit()
    return RedirectResponse(url=f"/monitors/{monitor_id}", status_code=302)

@router.post("/monitors/{monitor_id}/check-now")
async def check_now(monitor_id: int, request: Request, db: Session = Depends(get_db)):
    user = auth.get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    monitor = db.query(models.Monitor).filter(
        models.Monitor.id == monitor_id, models.Monitor.user_id == user.id
    ).first()
    if monitor:
        check_monitor(monitor_id)
    return RedirectResponse(url=f"/monitors/{monitor_id}", status_code=302)
