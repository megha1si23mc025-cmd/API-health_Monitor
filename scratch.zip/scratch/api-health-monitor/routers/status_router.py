from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import get_db
from datetime import datetime, timedelta
import models

router = APIRouter()
templates = Jinja2Templates(directory="templates")

@router.get("/status/{slug}", response_class=HTMLResponse)
async def public_status(slug: str, request: Request, db: Session = Depends(get_db)):
    monitor = db.query(models.Monitor).filter(models.Monitor.public_slug == slug).first()
    if not monitor:
        return HTMLResponse("<h1>Status page not found</h1>", status_code=404)
    since_30d = datetime.utcnow() - timedelta(days=30)
    checks = db.query(models.CheckHistory).filter(
        models.CheckHistory.monitor_id == monitor.id,
        models.CheckHistory.checked_at >= since_30d
    ).order_by(models.CheckHistory.checked_at.asc()).all()
    total = len(checks)
    up_count = sum(1 for c in checks if c.status == "up")
    uptime_percent = round((up_count / total * 100), 2) if total > 0 else 0
    incidents = db.query(models.Incident).filter(
        models.Incident.monitor_id == monitor.id
    ).order_by(models.Incident.started_at.desc()).limit(5).all()
    return templates.TemplateResponse("public_status.html", {
        "request": request, "monitor": monitor,
        "uptime_percent": uptime_percent, "incidents": incidents,
        "checks": checks[-90:], "total": total
    })
