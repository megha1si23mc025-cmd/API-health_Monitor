import requests as req_lib
import time
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from database import SessionLocal
import models

scheduler = BackgroundScheduler()

def check_monitor(monitor_id: int):
    db = SessionLocal()
    try:
        monitor = db.query(models.Monitor).filter(models.Monitor.id == monitor_id).first()
        if not monitor or not monitor.is_active:
            return
        start_time = time.time()
        status = "down"
        status_code = None
        error_message = None
        response_time_ms = None
        try:
            response = req_lib.request(
                monitor.method,
                monitor.url,
                timeout=monitor.timeout_seconds
            )
            response_time_ms = (time.time() - start_time) * 1000
            status_code = response.status_code
            if status_code == monitor.expected_status_code:
                status = "up" if response_time_ms < 2000 else "degraded"
            else:
                status = "down"
        except req_lib.exceptions.Timeout:
            error_message = "Request timed out"
            status = "down"
        except req_lib.exceptions.ConnectionError as e:
            error_message = str(e)[:200]
            status = "down"
        except Exception as e:
            error_message = str(e)[:200]
            status = "down"
        # Save check history
        check = models.CheckHistory(
            monitor_id=monitor_id,
            status=status,
            response_time_ms=response_time_ms,
            status_code=status_code,
            error_message=error_message,
            checked_at=datetime.utcnow()
        )
        db.add(check)
        # Handle incidents
        was_up = monitor.current_status == "up"
        is_down = status == "down"
        if is_down and was_up:
            incident = models.Incident(
                monitor_id=monitor_id,
                description=f"Monitor went down. Status code: {status_code}. Error: {error_message}",
                started_at=datetime.utcnow()
            )
            db.add(incident)
        elif status == "up":
            open_incident = db.query(models.Incident).filter(
                models.Incident.monitor_id == monitor_id,
                models.Incident.is_resolved == False
            ).first()
            if open_incident:
                open_incident.is_resolved = True
                open_incident.resolved_at = datetime.utcnow()
        # Update monitor
        monitor.current_status = status
        monitor.last_checked_at = datetime.utcnow()
        db.commit()
    except Exception as e:
        print(f"Scheduler error for monitor {monitor_id}: {e}")
    finally:
        db.close()

def schedule_monitor(monitor_id: int, interval_minutes: int):
    job_id = f"monitor_{monitor_id}"
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
    scheduler.add_job(
        check_monitor,
        "interval",
        minutes=interval_minutes,
        id=job_id,
        args=[monitor_id],
        replace_existing=True
    )

def remove_monitor_job(monitor_id: int):
    job_id = f"monitor_{monitor_id}"
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)

def start_scheduler():
    scheduler.start()
    db = SessionLocal()
    try:
        monitors = db.query(models.Monitor).filter(models.Monitor.is_active == True).all()
        for m in monitors:
            schedule_monitor(m.id, m.interval_minutes)
    finally:
        db.close()

def shutdown_scheduler():
    scheduler.shutdown(wait=False)
