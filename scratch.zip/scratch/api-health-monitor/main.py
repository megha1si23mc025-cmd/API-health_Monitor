from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from contextlib import asynccontextmanager
from database import engine, Base
from scheduler import start_scheduler, shutdown_scheduler
import models

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    start_scheduler()
    yield
    shutdown_scheduler()

app = FastAPI(title="PulseWatch - API Health Monitor", lifespan=lifespan)
templates = Jinja2Templates(directory="templates")

from routers import auth_router, monitors_router, status_router
app.include_router(auth_router.router)
app.include_router(monitors_router.router)
app.include_router(status_router.router)

@app.get("/")
async def root():
    return RedirectResponse(url="/dashboard")
