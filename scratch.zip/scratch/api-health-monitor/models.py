from sqlalchemy import Column, Integer, String, Boolean, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    monitors = relationship("Monitor", back_populates="owner", cascade="all, delete-orphan")

class Monitor(Base):
    __tablename__ = "monitors"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    name = Column(String, index=True)
    url = Column(String)
    method = Column(String, default="GET")
    interval_minutes = Column(Integer, default=5)
    is_active = Column(Boolean, default=True)
    expected_status_code = Column(Integer, default=200)
    timeout_seconds = Column(Integer, default=30)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_checked_at = Column(DateTime, nullable=True)
    current_status = Column(String, default="pending")
    public_slug = Column(String, unique=True, nullable=True)
    owner = relationship("User", back_populates="monitors")
    checks = relationship("CheckHistory", back_populates="monitor", cascade="all, delete-orphan", order_by="CheckHistory.checked_at.desc()")
    incidents = relationship("Incident", back_populates="monitor", cascade="all, delete-orphan")

class CheckHistory(Base):
    __tablename__ = "check_history"
    id = Column(Integer, primary_key=True, index=True)
    monitor_id = Column(Integer, ForeignKey("monitors.id"))
    status = Column(String)
    response_time_ms = Column(Float, nullable=True)
    status_code = Column(Integer, nullable=True)
    error_message = Column(Text, nullable=True)
    checked_at = Column(DateTime, default=datetime.utcnow)
    monitor = relationship("Monitor", back_populates="checks")

class Incident(Base):
    __tablename__ = "incidents"
    id = Column(Integer, primary_key=True, index=True)
    monitor_id = Column(Integer, ForeignKey("monitors.id"))
    started_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
    description = Column(Text)
    is_resolved = Column(Boolean, default=False)
    monitor = relationship("Monitor", back_populates="incidents")
