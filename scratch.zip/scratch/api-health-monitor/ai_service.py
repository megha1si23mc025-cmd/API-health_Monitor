import re
# ============================================================
# AI SERVICE — Plug in Ollama later by setting AI_ENABLED=True
# ============================================================
AI_ENABLED = False  # Flip to True after installing Ollama

OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_MODEL = "llama3"  # or mistral, gemma, etc.

def _ollama_call(prompt: str) -> str:
    try:
        import requests
        response = requests.post(
            f"{OLLAMA_BASE_URL}/api/generate",
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
            timeout=30
        )
        return response.json().get("response", "No response")
    except Exception as e:
        return f"Ollama error: {str(e)}"

def diagnose_failure(url: str, status_code: int, error_msg: str) -> str:
    if not AI_ENABLED:
        if status_code == 404:
            return "404 Not Found — The endpoint URL may be wrong or the resource was moved."
        elif status_code == 500:
            return "500 Server Error — The target server has an internal error. Contact the API owner."
        elif status_code == 403:
            return "403 Forbidden — Authentication or permission issue on the target API."
        elif status_code == 408 or "timeout" in error_msg.lower():
            return "Request Timeout — Server is slow or unreachable. Check network or increase timeout."
        elif status_code == 503:
            return "503 Service Unavailable — Server is overloaded or down for maintenance."
        elif not status_code:
            return "Connection Failed — Server is unreachable. Check URL, DNS, or if the service is running."
        else:
            return f"HTTP {status_code} — Unexpected response code. Check API documentation."
    prompt = f"Diagnose why this API endpoint failed. URL: {url}, Status Code: {status_code}, Error: {error_msg}. Give a 1-2 sentence diagnosis."
    return _ollama_call(prompt)

def get_uptime_insight(uptime_percent: float, avg_response_ms: float) -> str:
    if not AI_ENABLED:
        if uptime_percent >= 99.9:
            return "Excellent uptime. This endpoint is highly reliable."
        elif uptime_percent >= 99.0:
            return "Good uptime. Minor downtime observed. Monitor for patterns."
        elif uptime_percent >= 95.0:
            return "Moderate uptime. Consider investigating recurring downtime windows."
        else:
            return "Poor uptime. Immediate attention required. Check server health."
    prompt = f"Analyze this API monitor: uptime {uptime_percent:.1f}%, avg response {avg_response_ms:.0f}ms. Give a 1-sentence insight."
    return _ollama_call(prompt)
