# 🚀 PulseWatch — API Health Monitor & Uptime Dashboard

> A modern, full-stack Python web application to monitor API endpoints in real-time, track uptime, visualize response times, and auto-detect incidents.

---

## 📋 Table of Contents
- [Project Overview](#project-overview)
- [Tech Stack](#tech-stack)
- [Folder Structure](#folder-structure)
- [How to Run](#how-to-run)
- [Pages Explained](#pages-explained)
- [AI Upgrade Guide](#ai-upgrade-guide)
- [Resume Talking Points](#resume-talking-points)

---

## 🎯 Project Overview

PulseWatch monitors your API endpoints on a schedule, records uptime and response times, automatically creates incidents when endpoints go down, and provides:
- A private dashboard for monitoring all your endpoints
- Beautiful response time charts
- Shareable public status pages (like `status.stripe.com`)
- AI-powered failure diagnosis (plug in Ollama later)

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Backend | FastAPI (Python) |
| Database | SQLite + SQLAlchemy ORM |
| Auth | JWT stored in HTTP-only cookies (python-jose + passlib) |
| Templates | Jinja2 |
| Styling | Tailwind CSS (CDN — no install needed) |
| Charts | Chart.js (CDN) |
| Scheduler | APScheduler (background pings) |
| AI (later) | Ollama — `http://localhost:11434` (pure local, no SSL) |

---

## 📁 Folder Structure

```
api-health-monitor/
│
├── main.py                   ← FastAPI app entry, DB init, lifespan
├── database.py               ← SQLAlchemy engine + session + Base
├── models.py                 ← DB models: User, Monitor, CheckHistory, Incident
├── auth.py                   ← JWT cookie auth, password hashing
├── ai_service.py             ← Rule-based NOW / Ollama-ready LATER
├── scheduler.py              ← APScheduler background health checks
├── requirements.txt          ← All Python dependencies
│
├── routers/
│   ├── __init__.py
│   ├── auth_router.py        ← /login, /register, /logout routes
│   ├── monitors_router.py    ← /dashboard, /monitors/add, /monitors/{id}
│   └── status_router.py      ← /status/{slug} public page
│
└── templates/
    ├── base.html             ← Shared layout: dark sidebar + main content
    ├── login.html            ← Login page (standalone, no sidebar)
    ├── register.html         ← Register page (standalone)
    ├── dashboard.html        ← Main dashboard with stat cards + monitor list
    ├── add_monitor.html      ← Add new monitor form
    ├── monitor_detail.html   ← Charts, incidents, actions for one monitor
    └── public_status.html    ← Shareable public status page (no login needed)
```

---

## ▶️ How to Run

### Step 1 — Install dependencies
```bash
cd api-health-monitor
pip install -r requirements.txt
```

### Step 2 — Start the server
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Step 3 — Open in browser
```
http://localhost:8000
```
Register an account, add your first monitor, and you're live!

---

## 📄 Pages Explained

---

### 1. 🔐 Login Page — `/login`
**File:** `templates/login.html`

**What it shows:**
- Full-screen dark (slate-950) authentication page
- PulseWatch logo + branding
- Username + password form
- Error message display (wrong credentials)
- Link to register page

**What it does:**
- POSTs to `/login`
- Verifies password using bcrypt
- Creates JWT token and stores in HTTP-only cookie
- Redirects to `/dashboard` on success

---

### 2. 📝 Register Page — `/register`
**File:** `templates/register.html`

**What it shows:**
- Same dark full-screen layout as login
- Username, email, password fields
- Error messages (username taken, email exists)

**What it does:**
- POSTs to `/register`
- Hashes password using bcrypt
- Creates user in SQLite
- Auto-logs in and redirects to dashboard

---

### 3. 📊 Dashboard — `/dashboard`
**File:** `templates/dashboard.html`

**What it shows:**
- **Top stats bar**: 4 cards — Total Monitors, Operational (green), Down (red), Avg Response Time
- **Monitor list**: Each monitor as a row with animated status dot, URL, status badge, interval, last-checked time
- **Recent Incidents**: Last 5 incidents across all monitors
- Auto-refreshes every 30 seconds

**What it does:**
- Queries all monitors for current user
- Calculates avg response from last 24h check history
- Shows live status with color-coded badges

---

### 4. ➕ Add Monitor — `/monitors/add`
**File:** `templates/add_monitor.html`

**What it shows:**
- Clean form card (max-w-2xl, centered)
- Fields: Name, URL, HTTP Method (GET/POST/HEAD), Check Interval, Expected Status Code, Timeout
- Info box explaining first-check behavior

**What it does:**
- POSTs to `/monitors/add`
- Saves monitor to DB with auto-generated public slug
- Schedules background checker via APScheduler
- Runs first check immediately
- Redirects to monitor detail page

---

### 5. 📈 Monitor Detail — `/monitors/{id}`
**File:** `templates/monitor_detail.html`

**What it shows:**
- **Header**: Monitor name + URL + live status badge + action buttons
- **Stat cards**: Uptime % (last 24h), Avg Response Time, Last Checked time
- **Insight box** (indigo): AI-powered or rule-based uptime insight
- **Diagnosis box** (red, only when DOWN): Explains what went wrong
- **Response Time Chart**: Line chart via Chart.js, last 24h, indigo color
- **Public Status Page link**: Button to share status page URL
- **Incident History**: Table of all incidents with timestamps

**Action buttons:**
- `Check Now` — triggers immediate health check
- `Pause / Resume` — toggles scheduler on/off
- `Delete` — removes monitor and all history

---

### 6. 🌐 Public Status Page — `/status/{slug}`
**File:** `templates/public_status.html`

**What it shows:**
- No login required — shareable with anyone
- Large status banner: green (Operational) / red (Disruption) / amber (Degraded)
- Uptime % over last 30 days
- **Visual uptime bar**: each past check shown as a colored block (green/red/amber)
- Recent incidents list

**Use case:** Share `http://localhost:8000/status/abc123` with your users to show real-time service health — just like `status.stripe.com` or `status.github.com`

---

## 🤖 AI Upgrade Guide

When you're ready to add AI, just install Ollama and flip one switch:

### Step 1 — Install Ollama
Download from [ollama.com](https://ollama.com) and run:
```bash
ollama pull llama3
```

### Step 2 — Enable AI in code
Open `ai_service.py` and change:
```python
AI_ENABLED = False   # Change this to:
AI_ENABLED = True
```

### Step 3 — That's it!
No other changes needed. The app will now:
- **Diagnose failures** using LLaMA 3 instead of hardcoded rules
- **Generate uptime insights** using real language understanding

**How it calls Ollama:**
```python
requests.post("http://localhost:11434/api/generate", json={
    "model": "llama3",
    "prompt": "...",
    "stream": False
})
```
Pure HTTP to localhost. Zero SSL. Zero internet.

---

## 🏆 Resume Talking Points

| Feature | What to say |
|---|---|
| Background Scheduler | "Implemented APScheduler to ping endpoints on a configurable interval without blocking the main thread" |
| JWT Auth | "Used JWT tokens stored in HTTP-only cookies for secure, stateless authentication" |
| Incident Management | "Built automatic incident creation and resolution tracking — detects when a monitor goes down and auto-resolves when it recovers" |
| Response Time Charts | "Integrated Chart.js for real-time response time visualization over a rolling 24-hour window" |
| Public Status Pages | "Designed shareable public status pages with uptime history visualization — similar to status.stripe.com" |
| AI-Ready Architecture | "Architected the AI service layer with a rule-based fallback, designed so a local Ollama LLM can be plugged in by flipping one boolean" |
| SQLAlchemy ORM | "Used SQLAlchemy with relationship cascades for clean relational data modeling across 4 entities" |

---

## 📌 Notes

- **Database**: `api_monitor.db` SQLite file is auto-created on first run — no setup needed
- **No internet required at runtime**: All CSS/JS loaded from CDN (browser side), server is 100% offline-capable
- **SSL**: Zero SSL issues — no external API calls from Python server side
- **Port**: Runs on `http://localhost:8000` by default
